import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

async function main() {
  console.log('🌱 Starting seed...');

  // Clear existing data
  await prisma.project.deleteMany({});
  await prisma.client.deleteMany({});
  await prisma.admin.deleteMany({});

  // Create admin user
  const admin = await prisma.admin.create({
    data: {
      username: 'admin',
      password: 'RealTrust@2025',
    },
  });
  console.log('✅ Admin user created:', admin.username);

  // Create sample projects with real world screenshots
  const projects = [
    {
      name: 'TechCorp E-Commerce Platform',
      description: 'A full-featured e-commerce platform built with Next.js and Node.js, featuring real-time inventory management, payment integration, and a modern responsive design.',
      imageUrl: 'https://images.unsplash.com/photo-1556742049-0d9d3e80c8?auto=format&fit=crop&w=800&q=80',
    },
    {
      name: 'HealthCare Plus Application',
      description: 'A healthcare management system that streamlines patient appointments, medical records, and billing. Built with secure authentication and HIPAA compliance features.',
      imageUrl: 'https://images.unsplash.com/photo-1576091160550-2173dba999ef?auto=format&fit=crop&w=800&q=80',
    },
    {
      name: 'FinanceFlow Dashboard',
      description: 'An intuitive financial dashboard for tracking investments, expenses, and budgets. Includes interactive charts, real-time data updates, and comprehensive reporting.',
      imageUrl: 'https://images.unsplash.com/photo-1551288049-bebda4e38f3?auto=format&fit=crop&w=800&q=80',
    },
    {
      name: 'SocialConnect Network',
      description: 'A modern social networking platform with real-time messaging, content sharing, and community features. Designed for scalability and high-performance.',
      imageUrl: 'https://images.unsplash.com/photo-1611162616475-46b635cd6842?auto=format&fit=crop&w=800&q=80',
    },
    {
      name: 'EduLearn Learning Platform',
      description: 'An online learning management system with course creation, progress tracking, and interactive assessments. Supports video streaming and live classes.',
      imageUrl: 'https://images.unsplash.com/photo-150150490525-c4b5eaa4cc0?auto=format&fit=crop&w=800&q=80',
    },
    {
      name: 'TravelBook Explorer',
      description: 'A travel booking platform featuring destination guides, hotel reservations, and itinerary planning. Integrated with multiple travel APIs for real-time availability.',
      imageUrl: 'https://images.unsplash.com/photo-1469852625309-4db5802d5d3?auto=format&fit=crop&w=800&q=80',
    },
  ];

  for (const project of projects) {
    await prisma.project.create({
      data: project,
    });
  }
  console.log('✅ Created 6 sample projects');

  // Create sample clients with real professional photos
  const clients = [
    {
      name: 'Sarah Johnson',
      description: 'Working with REAL TRUST was an absolute pleasure. They delivered our project on time and exceeded our expectations with quality of work. The attention to detail and professionalism is outstanding.',
      designation: 'CEO',
      imageUrl: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=400&q=80',
    },
    {
      name: 'Michael Chen',
      description: 'The development team demonstrated exceptional technical expertise and problem-solving skills. Our web application has been performing flawlessly since launch. Highly recommended!',
      designation: 'CTO',
      imageUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=400&q=80',
    },
    {
      name: 'Emily Rodriguez',
      description: 'I was impressed by their ability to understand our vision and translate it into a stunning digital presence. The communication throughout project was excellent.',
      designation: 'Marketing Director',
      imageUrl: 'https://images.unsplash.com/photo-1580489944763-269b2d68d5a3?auto=format&fit=crop&w=400&q=80',
    },
    {
      name: 'David Thompson',
      description: 'Their solution helped us streamline our operations and increase efficiency by 40%. The user interface is intuitive and our team adapted to it quickly.',
      designation: 'Project Manager',
      imageUrl: 'https://images.unsplash.com/photo-1472099645785-5e8ec02f06c7?auto=format&fit=crop&w=400&q=80',
    },
    {
      name: 'Jennifer Williams',
      description: 'Outstanding work! The team was responsive to all our feedback and implemented changes promptly. The final product exceeded our requirements.',
      designation: 'Product Owner',
      imageUrl: 'https://images.unsplash.com/photo-1438761681033-6461ffdb8118?auto=format&fit=crop&w=400&q=80',
    },
    {
      name: 'Robert Kim',
      description: 'Professional, skilled, and dedicated. They transformed our outdated system into a modern, efficient platform. The ROI has been tremendous.',
      designation: 'Business Analyst',
      imageUrl: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=400&q=80',
    },
  ];

  for (const client of clients) {
    await prisma.client.create({
      data: client,
    });
  }
  console.log('✅ Created 6 sample clients');

  console.log('🎉 Seed completed successfully!');
}

main()
  .catch((e) => {
    console.error('❌ Seed failed:', e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
