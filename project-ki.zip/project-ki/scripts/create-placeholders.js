import sharp from 'sharp';
import { writeFile } from 'fs/promises';
import path from 'path';

async function createPlaceholder(type, index, width = 450, height = 350) {
  const colors = [
    { bg: '#3B82F6', text: '#FFFFFF' }, // Blue
    { bg: '#10B981', text: '#FFFFFF' }, // Green
    { bg: '#F59E0B', text: '#FFFFFF' }, // Orange
    { bg: '#8B5CF6', text: '#FFFFFF' }, // Purple
    { bg: '#EF4444', text: '#FFFFFF' }, // Red
    { bg: '#06B6D4', text: '#FFFFFF' }, // Cyan
  ];

  const color = colors[index % colors.length];
  const displayType = type === 'projects' ? 'Project' : 'Client';
  const svg = `
    <svg width="${width}" height="${height}" xmlns="http://www.w3.org/2000/svg">
      <rect width="100%" height="100%" fill="${color.bg}"/>
      <text x="50%" y="50%" font-family="Arial, sans-serif" font-size="24" font-weight="bold" fill="${color.text}" text-anchor="middle" dy=".3em">
        ${displayType} ${index + 1}
      </text>
    </svg>
  `;

  const filename = `placeholder-${index + 1}.jpg`;
  const outputPath = path.join(process.cwd(), 'public', 'uploads', type, filename);

  await sharp(Buffer.from(svg))
    .jpeg({ quality: 85 })
    .toFile(outputPath);

  console.log(`✓ Created: ${outputPath}`);
  return `/uploads/${type}/${filename}`;
}

async function createAllPlaceholders() {
  console.log('🎨 Creating placeholder images...\n');

  // Create project placeholders
  console.log('Creating project images:');
  for (let i = 0; i < 6; i++) {
    await createPlaceholder('projects', i);
  }

  // Create client placeholders
  console.log('\nCreating client images:');
  for (let i = 0; i < 6; i++) {
    await createPlaceholder('clients', i);
  }

  console.log('\n✅ All placeholder images created successfully!');
}

createAllPlaceholders().catch(console.error);
