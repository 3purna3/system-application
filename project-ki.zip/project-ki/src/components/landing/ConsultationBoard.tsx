'use client';

import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Phone, Mail, MessageSquare, X } from 'lucide-react';
import { toast } from '@/hooks/use-toast';

export function ConsultationBoard() {
  const [isOpen, setIsOpen] = useState(true);
  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    email: '',
    message: '',
  });
  const [submitting, setSubmitting] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);

    try {
      const response = await fetch('/api/contact', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: formData.name,
          mobile: formData.phone,
          email: formData.email,
          city: 'Online Inquiry',
        }),
      });

      if (response.ok) {
        toast({
          title: 'Consultation Request Sent!',
          description: 'We will contact you within 24 hours.',
        });
        setFormData({ name: '', phone: '', email: '', message: '' });
      }
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to send request. Please try again.',
        variant: 'destructive',
      });
    } finally {
      setSubmitting(false);
    }
  };

  if (!isOpen) {
    return (
      <Button
        onClick={() => setIsOpen(true)}
        className="fixed bottom-6 right-6 z-50 bg-gradient-to-r from-emerald-600 to-teal-600 shadow-lg rounded-full h-14 w-14 p-0"
      >
        <MessageSquare className="h-6 w-6" />
      </Button>
    );
  }

  return (
    <div className="fixed top-24 right-4 md:right-8 z-50 w-80 md:w-96">
      <div className="bg-white rounded-2xl shadow-2xl border border-gray-200 overflow-hidden">
        {/* Header */}
        <div className="bg-gradient-to-r from-emerald-600 to-teal-600 p-4">
          <div className="flex items-center justify-between text-white">
            <div>
              <h3 className="font-bold text-lg">Quick Consultation</h3>
              <p className="text-sm opacity-90">Get expert advice now</p>
            </div>
            <Button
              variant="ghost"
              size="icon"
              className="text-white hover:bg-white/20"
              onClick={() => setIsOpen(false)}
            >
              <X className="h-5 w-5" />
            </Button>
          </div>
        </div>

        {/* Content */}
        <div className="p-4 bg-gradient-to-b from-emerald-50 to-white">
          <div className="space-y-3 mb-4">
            <div className="flex items-center gap-3 p-3 bg-white rounded-lg shadow-sm">
              <div className="h-10 w-10 rounded-full bg-emerald-100 flex items-center justify-center">
                <Phone className="h-5 w-5 text-emerald-600" />
              </div>
              <div>
                <p className="text-sm font-medium">Call Us</p>
                <p className="text-sm text-emerald-600 font-semibold">+1 234 567 8900</p>
              </div>
            </div>

            <div className="flex items-center gap-3 p-3 bg-white rounded-lg shadow-sm">
              <div className="h-10 w-10 rounded-full bg-teal-100 flex items-center justify-center">
                <Mail className="h-5 w-5 text-teal-600" />
              </div>
              <div>
                <p className="text-sm font-medium">Email Us</p>
                <p className="text-sm text-teal-600 font-semibold">consult@realtrust.com</p>
              </div>
            </div>
          </div>

          <form onSubmit={handleSubmit} className="space-y-3">
            <Input
              placeholder="Your Name"
              required
              value={formData.name}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              className="bg-white"
            />
            <Input
              type="tel"
              placeholder="Phone Number"
              required
              value={formData.phone}
              onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
              className="bg-white"
            />
            <Input
              type="email"
              placeholder="Email Address"
              required
              value={formData.email}
              onChange={(e) => setFormData({ ...formData, email: e.target.value })}
              className="bg-white"
            />
            <Button
              type="submit"
              className="w-full bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700"
              disabled={submitting}
            >
              {submitting ? 'Sending...' : 'Request Consultation'}
            </Button>
          </form>
        </div>
      </div>
    </div>
  );
}
