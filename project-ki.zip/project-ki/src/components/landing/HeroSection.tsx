'use client';

import { Button } from '@/components/ui/button';
import { ArrowRight, TrendingUp, Shield, Users, Award } from 'lucide-react';

export function HeroSection() {
  return (
    <section
      id="hero"
      className="relative min-h-screen flex items-center bg-gradient-to-br from-slate-50 via-emerald-50 to-teal-50"
    >
      {/* Background Pattern */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute top-20 right-20 w-96 h-96 bg-emerald-200/20 rounded-full blur-3xl" />
        <div className="absolute bottom-20 left-20 w-96 h-96 bg-teal-200/20 rounded-full blur-3xl" />
      </div>

      <div className="container mx-auto px-4 md:px-8 relative z-10">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Left Content */}
          <div className="space-y-8">
            <div className="inline-flex items-center rounded-full bg-emerald-100 px-4 py-2 text-sm font-medium text-emerald-700 mb-4">
              <TrendingUp className="h-4 w-4 mr-2" />
              Trusted by 500+ Companies Worldwide
            </div>

            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold leading-tight">
              Building Your
              <span className="block bg-gradient-to-r from-emerald-600 to-teal-600 bg-clip-text text-transparent mt-2">
                Digital Future
              </span>
            </h1>

            <p className="text-xl text-slate-600 leading-relaxed">
              REAL TRUST delivers innovative digital solutions that transform businesses. From
              web development to enterprise systems, we bring your vision to life.
            </p>

            <div className="flex flex-col sm:flex-row gap-4">
              <Button
                size="lg"
                className="bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 h-14 text-base px-8"
                onClick={() => {
                  const el = document.getElementById('contact');
                  if (el) el.scrollIntoView({ behavior: 'smooth' });
                }}
              >
                Start Your Project <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
              <Button
                size="lg"
                variant="outline"
                className="h-14 text-base px-8 border-emerald-300 text-emerald-700 hover:bg-emerald-50"
                onClick={() => {
                  const el = document.getElementById('projects');
                  if (el) el.scrollIntoView({ behavior: 'smooth' });
                }}
              >
                View Our Work
              </Button>
            </div>

            {/* Stats */}
            <div className="grid grid-cols-3 gap-6 pt-8">
              <div>
                <div className="text-3xl font-bold text-emerald-600">500+</div>
                <div className="text-sm text-slate-600">Projects Completed</div>
              </div>
              <div>
                <div className="text-3xl font-bold text-teal-600">98%</div>
                <div className="text-sm text-slate-600">Client Satisfaction</div>
              </div>
              <div>
                <div className="text-3xl font-bold text-emerald-600">10+</div>
                <div className="text-sm text-slate-600">Years Experience</div>
              </div>
            </div>
          </div>

          {/* Right Content - Feature Cards */}
          <div className="hidden lg:grid lg:grid-cols-2 gap-4">
            <div className="bg-white/80 backdrop-blur rounded-2xl p-6 shadow-lg border border-emerald-100 hover:shadow-xl transition-shadow">
              <div className="h-12 w-12 rounded-xl bg-emerald-100 flex items-center justify-center mb-4">
                <Shield className="h-6 w-6 text-emerald-600" />
              </div>
              <h3 className="font-bold text-lg mb-2">Secure Solutions</h3>
              <p className="text-sm text-slate-600">
                Enterprise-grade security for all your digital assets and data.
              </p>
            </div>

            <div className="bg-white/80 backdrop-blur rounded-2xl p-6 shadow-lg border border-teal-100 mt-8 hover:shadow-xl transition-shadow">
              <div className="h-12 w-12 rounded-xl bg-teal-100 flex items-center justify-center mb-4">
                <Users className="h-6 w-6 text-teal-600" />
              </div>
              <h3 className="font-bold text-lg mb-2">Expert Team</h3>
              <p className="text-sm text-slate-600">
                Skilled professionals dedicated to your project success.
              </p>
            </div>

            <div className="bg-white/80 backdrop-blur rounded-2xl p-6 shadow-lg border border-emerald-100 mt-4 hover:shadow-xl transition-shadow">
              <div className="h-12 w-12 rounded-xl bg-emerald-100 flex items-center justify-center mb-4">
                <Award className="h-6 w-6 text-emerald-600" />
              </div>
              <h3 className="font-bold text-lg mb-2">Quality First</h3>
              <p className="text-sm text-slate-600">
                Rigorous quality standards ensure flawless deliverables.
              </p>
            </div>

            <div className="bg-white/80 backdrop-blur rounded-2xl p-6 shadow-lg border border-teal-100 mt-12 hover:shadow-xl transition-shadow">
              <div className="h-12 w-12 rounded-xl bg-teal-100 flex items-center justify-center mb-4">
                <TrendingUp className="h-6 w-6 text-teal-600" />
              </div>
              <h3 className="font-bold text-lg mb-2">Growth Focused</h3>
              <p className="text-sm text-slate-600">
                Solutions designed to drive your business growth.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
