'use client';

import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent } from '@/components/ui/card';
import { toast } from '@/hooks/use-toast';
import { Mail, Bell } from 'lucide-react';

export function NewsletterSection() {
  const [email, setEmail] = useState('');
  const [subscribing, setSubscribing] = useState(false);

  const handleSubscribe = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubscribing(true);

    try {
      const response = await fetch('/api/subscribers', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email }),
      });

      if (response.ok) {
        toast({
          title: 'Successfully Subscribed!',
          description: 'Thank you for subscribing to our newsletter.',
        });
        setEmail('');
      } else {
        const data = await response.json();
        throw new Error(data.error || 'Failed to subscribe');
      }
    } catch (error) {
      toast({
        title: 'Error',
        description:
          error instanceof Error
            ? error.message
            : 'Failed to subscribe. Please try again.',
        variant: 'destructive',
      });
    } finally {
      setSubscribing(false);
    }
  };

  return (
    <section className="py-20 md:py-32 bg-gradient-to-r from-emerald-600 to-teal-600">
      <div className="container mx-auto px-4 md:px-8">
        <div className="max-w-4xl mx-auto">
          <Card className="bg-white rounded-3xl overflow-hidden shadow-2xl">
            <CardContent className="p-8 md:p-12">
              <div className="grid md:grid-cols-2 gap-8 items-center">
                {/* Left Content */}
                <div className="space-y-6">
                  <div className="inline-flex items-center rounded-full bg-emerald-100 px-4 py-2 text-sm font-medium text-emerald-700">
                    <Bell className="h-4 w-4 mr-2" />
                    Stay Updated
                  </div>

                      <h2 className="text-3xl md:text-4xl font-bold">
                        Subscribe to Our{' '}
                        <span className="block bg-gradient-to-r from-emerald-600 to-teal-600 bg-clip-text text-transparent mt-2">
                          Newsletter
                        </span>
                      </h2>

                      <p className="text-lg text-slate-600 leading-relaxed">
                        Get the latest updates, industry insights, and exclusive tips
                        delivered straight to your inbox. Join our community of
                        forward-thinking businesses and individuals.
                      </p>

                      <div className="space-y-4 pt-4">
                        <div className="flex items-center gap-3">
                          <div className="h-6 w-6 rounded-full bg-emerald-100 flex items-center justify-center flex-shrink-0">
                            <Mail className="h-3 w-3 text-emerald-600" />
                          </div>
                          <span className="text-slate-600">
                            Weekly curated content for professionals
                          </span>
                        </div>
                        <div className="flex items-center gap-3">
                          <div className="h-6 w-6 rounded-full bg-teal-100 flex items-center justify-center flex-shrink-0">
                            <Bell className="h-3 w-3 text-teal-600" />
                          </div>
                          <span className="text-slate-600">
                            Exclusive project insights and trends
                          </span>
                        </div>
                        <div className="flex items-center gap-3">
                          <div className="h-6 w-6 rounded-full bg-emerald-100 flex items-center justify-center flex-shrink-0">
                            <Mail className="h-3 w-3 text-emerald-600" />
                          </div>
                          <span className="text-slate-600">
                            No spam, unsubscribe anytime
                          </span>
                        </div>
                      </div>
                    </div>

                    {/* Right Content - Form */}
                    <div>
                      <form onSubmit={handleSubscribe} className="space-y-4">
                        <div className="space-y-2">
                          <label className="text-sm font-semibold text-slate-700">
                            Email Address
                          </label>
                          <Input
                            required
                            type="email"
                            placeholder="Enter your email"
                            value={email}
                            onChange={(e) => setEmail(e.target.value)}
                            className="h-14 text-base"
                          />
                        </div>
                        <Button
                          type="submit"
                          className="w-full h-14 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-base font-semibold"
                          disabled={subscribing}
                        >
                          {subscribing ? 'Subscribing...' : 'Subscribe Now'}
                        </Button>
                        <p className="text-sm text-slate-500 text-center pt-2">
                          By subscribing, you agree to receive marketing emails
                        </p>
                      </form>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>
      );
}
