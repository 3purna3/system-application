'use client';

import {
  Zap,
  ShieldCheck,
  Clock,
  HeadphonesIcon,
  DollarSign,
  TrendingUp,
} from 'lucide-react';

export function WhyChooseUsSection() {
  const reasons = [
    {
      icon: Zap,
      title: 'Lightning Fast',
      description:
        'We deliver projects on time with optimized performance and quick turnaround times.',
    },
    {
      icon: ShieldCheck,
      title: 'Secure & Reliable',
      description:
        'Enterprise-grade security protocols protect your data and ensure system reliability.',
    },
    {
      icon: Clock,
      title: '24/7 Support',
      description:
        'Round-the-clock technical support to keep your business running smoothly.',
    },
    {
      icon: HeadphonesIcon,
      title: 'Expert Consultation',
      description:
        'Our experienced team provides strategic guidance tailored to your business needs.',
    },
    {
      icon: DollarSign,
      title: 'Cost Effective',
      description:
        'Competitive pricing without compromising on quality or features.',
    },
    {
      icon: TrendingUp,
      title: 'Scalable Solutions',
      description:
        'Build solutions that grow with your business, adapting to future needs.',
    },
  ];

  return (
    <section id="why-choose-us" className="py-20 md:py-32 bg-gradient-to-b from-slate-50 to-white">
      <div className="container mx-auto px-4 md:px-8">
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <div className="inline-flex items-center rounded-full bg-emerald-100 px-4 py-2 text-sm font-medium text-emerald-700 mb-4">
            Why Choose Us
          </div>
          <h2 className="text-3xl md:text-4xl font-bold mb-6">
            What Makes REAL TRUST
            <span className="block bg-gradient-to-r from-emerald-600 to-teal-600 bg-clip-text text-transparent mt-2">
              Your Perfect Partner
            </span>
          </h2>
          <p className="text-lg text-slate-600">
            We combine expertise, innovation, and dedication to deliver results that exceed
            expectations. Discover why leading businesses trust us with their digital transformation.
          </p>
        </div>

        {/* Reasons Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {reasons.map((reason, index) => (
            <div
              key={index}
              className="bg-white rounded-2xl p-8 shadow-lg hover:shadow-2xl transition-all duration-300 hover:-translate-y-2 border border-emerald-50"
            >
              <div className="h-14 w-14 rounded-xl bg-gradient-to-br from-emerald-500 to-teal-500 flex items-center justify-center mb-6">
                <reason.icon className="h-7 w-7 text-white" />
              </div>
              <h3 className="text-xl font-bold mb-3 text-slate-800">
                {reason.title}
              </h3>
              <p className="text-slate-600 leading-relaxed">
                {reason.description}
              </p>
            </div>
          ))}
        </div>

        {/* CTA */}
        <div className="mt-16 text-center">
          <div className="bg-gradient-to-r from-emerald-600 to-teal-600 rounded-2xl p-8 md:p-12 text-white">
            <h3 className="text-2xl md:text-3xl font-bold mb-4">
              Ready to Start Your Project?
            </h3>
            <p className="text-lg opacity-90 mb-6 max-w-2xl mx-auto">
              Let's discuss how we can help you achieve your digital transformation goals.
              Get a free consultation today!
            </p>
            <button
              onClick={() => {
                const el = document.getElementById('contact');
                if (el) el.scrollIntoView({ behavior: 'smooth' });
              }}
              className="bg-white text-emerald-700 font-semibold px-8 py-4 rounded-xl hover:bg-emerald-50 transition-colors inline-block"
            >
              Schedule Free Consultation
            </button>
          </div>
        </div>
      </div>
    </section>
  );
}
