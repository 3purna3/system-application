'use client';

import { useState, useEffect } from 'react';
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { ArrowRight, Code2, Database, Globe, Smartphone, Zap, Shield } from 'lucide-react';
import { Skeleton } from '@/components/ui/skeleton';

const projectIcons = [
  Code2, Database, Globe, Smartphone, Zap, Shield,
];

export function ProjectsSection() {
  const [projects, setProjects] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchProjects();
  }, []);

  const fetchProjects = async () => {
    try {
      const response = await fetch('/api/projects');
      const data = await response.json();
      setProjects(data);
    } catch (error) {
      console.error('Error fetching projects:', error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <section id="projects" className="py-20 md:py-32 bg-gradient-to-b from-white to-slate-50">
      <div className="container mx-auto px-4 md:px-8">
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <div className="inline-flex items-center rounded-full bg-emerald-100 px-4 py-2 text-sm font-medium text-emerald-700 mb-4">
            Our Projects
          </div>
          <h2 className="text-3xl md:text-4xl font-bold mb-6">
            Featured Work That
            <span className="block bg-gradient-to-r from-emerald-600 to-teal-600 bg-clip-text text-transparent mt-2">
              Defines Excellence
            </span>
          </h2>
          <p className="text-lg text-slate-600">
            Explore our portfolio of successful projects that showcase our expertise and
            commitment to delivering exceptional digital solutions.
          </p>
        </div>

        {/* Projects Grid */}
        {loading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[1, 2, 3, 4, 5, 6].map((i) => (
              <Card key={i} className="h-[500px]">
                <Skeleton className="h-64 w-full" />
                <CardHeader>
                  <Skeleton className="h-6 w-3/4" />
                  <Skeleton className="h-4 w-full" />
                  <Skeleton className="h-4 w-2/3" />
                </CardHeader>
              </Card>
            ))}
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {projects.map((project, index) => {
              const Icon = projectIcons[index % projectIcons.length];
              return (
                <Card
                  key={project.id}
                  className="h-[500px] flex flex-col overflow-hidden hover:shadow-2xl transition-all duration-300 hover:-translate-y-2 border-emerald-100"
                >
                  {/* Project Image */}
                  <div className="h-64 overflow-hidden relative">
                    <img
                      src={project.imageUrl}
                      alt={project.name}
                      className="w-full h-full object-cover hover:scale-110 transition-transform duration-500"
                    />
                    <div className="absolute top-4 right-4 bg-white/90 backdrop-blur rounded-lg px-3 py-1 text-sm font-medium text-emerald-700">
                      <div className="flex items-center gap-1">
                        <Icon className="h-4 w-4" />
                        Featured
                      </div>
                    </div>
                  </div>

                  {/* Project Details */}
                  <CardHeader className="flex-1">
                    <CardTitle className="text-xl mb-3 line-clamp-1">
                      {project.name}
                    </CardTitle>
                    <p className="text-slate-600 line-clamp-3 leading-relaxed">
                      {project.description}
                    </p>
                  </CardHeader>

                  {/* Footer with Read More */}
                  <CardFooter className="pt-0">
                    <Button
                      variant="outline"
                      className="w-full border-emerald-300 text-emerald-700 hover:bg-emerald-50 group"
                    >
                      Read More
                      <ArrowRight className="ml-2 h-4 w-4 group-hover:translate-x-1 transition-transform" />
                    </Button>
                  </CardFooter>
                </Card>
              );
            })}
          </div>
        )}

        {/* View All CTA */}
        <div className="mt-16 text-center">
          <button
            onClick={() => {
              const el = document.getElementById('contact');
              if (el) el.scrollIntoView({ behavior: 'smooth' });
            }}
            className="bg-gradient-to-r from-emerald-600 to-teal-600 text-white font-semibold px-8 py-4 rounded-xl hover:from-emerald-700 hover:to-teal-700 transition-colors"
          >
            Discuss Your Project
          </button>
        </div>
      </div>
    </section>
  );
}
