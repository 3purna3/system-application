'use client';

import { Mail, Phone, MapPin, Facebook, Twitter, Linkedin, Instagram, ArrowUp } from 'lucide-react';
import { Button } from '@/components/ui/button';

export function Footer() {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="bg-slate-900 text-white mt-auto">
      <div className="container mx-auto px-4 md:px-8 py-16">
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-12 mb-12">
          {/* About */}
          <div className="space-y-6">
            <div className="flex items-center gap-3">
              <div className="h-12 w-12 rounded-lg bg-gradient-to-br from-emerald-500 to-teal-500 flex items-center justify-center">
                <span className="text-white font-bold text-2xl">RT</span>
              </div>
              <div>
                <span className="text-2xl font-bold">REAL TRUST</span>
              </div>
            </div>
            <p className="text-slate-400 leading-relaxed">
              Building exceptional digital experiences that drive business growth. Your
              trusted partner for web development and digital transformation.
            </p>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="font-bold text-lg mb-6">Quick Links</h3>
            <ul className="space-y-3">
              <li>
                <button
                  onClick={() => {
                    const el = document.getElementById('about');
                    if (el) el.scrollIntoView({ behavior: 'smooth' });
                  }}
                  className="text-slate-400 hover:text-emerald-400 transition-colors text-left w-full"
                >
                  About Us
                </button>
              </li>
              <li>
                <button
                  onClick={() => {
                    const el = document.getElementById('projects');
                    if (el) el.scrollIntoView({ behavior: 'smooth' });
                  }}
                  className="text-slate-400 hover:text-emerald-400 transition-colors text-left w-full"
                >
                  Our Projects
                </button>
              </li>
              <li>
                <button
                  onClick={() => {
                    const el = document.getElementById('clients');
                    if (el) el.scrollIntoView({ behavior: 'smooth' });
                  }}
                  className="text-slate-400 hover:text-emerald-400 transition-colors text-left w-full"
                >
                  Happy Clients
                </button>
              </li>
              <li>
                <button
                  onClick={() => {
                    const el = document.getElementById('contact');
                    if (el) el.scrollIntoView({ behavior: 'smooth' });
                  }}
                  className="text-slate-400 hover:text-emerald-400 transition-colors text-left w-full"
                >
                  Contact
                </button>
              </li>
            </ul>
          </div>

          {/* Contact Info */}
          <div>
            <h3 className="font-bold text-lg mb-6">Contact Info</h3>
            <ul className="space-y-4">
              <li className="flex items-start gap-3">
                <Mail className="h-5 w-5 text-emerald-400 flex-shrink-0 mt-0.5" />
                <div>
                  <p className="font-medium">Email</p>
                  <p className="text-slate-400">info@realtrust.com</p>
                </div>
              </li>
              <li className="flex items-start gap-3">
                <Phone className="h-5 w-5 text-emerald-400 flex-shrink-0 mt-0.5" />
                <div>
                  <p className="font-medium">Phone</p>
                  <p className="text-slate-400">+1 234 567 8900</p>
                </div>
              </li>
              <li className="flex items-start gap-3">
                <MapPin className="h-5 w-5 text-emerald-400 flex-shrink-0 mt-0.5" />
                <div>
                  <p className="font-medium">Location</p>
                  <p className="text-slate-400">New York, USA</p>
                </div>
              </li>
            </ul>
          </div>

          {/* Social Links */}
          <div>
            <h3 className="font-bold text-lg mb-6">Follow Us</h3>
            <div className="grid grid-cols-2 gap-3">
              <Button
                variant="outline"
                className="border-slate-700 text-white hover:bg-emerald-600 hover:border-emerald-600 h-12"
              >
                <Facebook className="h-5 w-5 mr-2" />
                Facebook
              </Button>
              <Button
                variant="outline"
                className="border-slate-700 text-white hover:bg-emerald-600 hover:border-emerald-600 h-12"
              >
                <Twitter className="h-5 w-5 mr-2" />
                Twitter
              </Button>
              <Button
                variant="outline"
                className="border-slate-700 text-white hover:bg-emerald-600 hover:border-emerald-600 h-12"
              >
                <Instagram className="h-5 w-5 mr-2" />
                Instagram
              </Button>
              <Button
                variant="outline"
                className="border-slate-700 text-white hover:bg-emerald-600 hover:border-emerald-600 h-12"
              >
                <Linkedin className="h-5 w-5 mr-2" />
                LinkedIn
              </Button>
            </div>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="border-t border-slate-800 pt-8">
          <div className="flex flex-col md:flex-row justify-between items-center gap-4">
            <p className="text-slate-400 text-sm">
              © 2025 REAL TRUST. All rights reserved.
            </p>
            <Button
              onClick={scrollToTop}
              variant="outline"
              size="sm"
              className="border-slate-700 text-white hover:bg-emerald-600 hover:border-emerald-600"
            >
              <ArrowUp className="h-4 w-4 mr-2" />
              Back to Top
            </Button>
          </div>
        </div>
      </div>
    </footer>
  );
}
