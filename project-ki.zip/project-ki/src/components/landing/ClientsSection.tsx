'use client';

import { useState, useEffect } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Star, Quote } from 'lucide-react';
import { Skeleton } from '@/components/ui/skeleton';

export function ClientsSection() {
  const [clients, setClients] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchClients();
  }, []);

  const fetchClients = async () => {
    try {
      const response = await fetch('/api/clients');
      const data = await response.json();
      setClients(data);
    } catch (error) {
      console.error('Error fetching clients:', error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <section id="clients" className="py-20 md:py-32 bg-white">
      <div className="container mx-auto px-4 md:px-8">
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <div className="inline-flex items-center rounded-full bg-teal-100 px-4 py-2 text-sm font-medium text-teal-700 mb-4">
            Happy Clients
          </div>
          <h2 className="text-3xl md:text-4xl font-bold mb-6">
            What Our Clients
            <span className="block bg-gradient-to-r from-emerald-600 to-teal-600 bg-clip-text text-transparent mt-2">
              Say About Us
            </span>
          </h2>
          <p className="text-lg text-slate-600">
            Don't just take our word for it. Here's what our valued clients
            have to say about working with REAL TRUST.
          </p>
        </div>

        {/* Clients Grid */}
        {loading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[1, 2, 3, 4, 5, 6].map((i) => (
              <Card key={i} className="h-[380px]">
                <CardContent className="pt-6">
                  <div className="flex items-center gap-4 mb-4">
                    <Skeleton className="h-16 w-16 rounded-full" />
                    <div className="space-y-2">
                      <Skeleton className="h-5 w-32" />
                      <Skeleton className="h-4 w-24" />
                    </div>
                  </div>
                  <Skeleton className="h-4 w-full" />
                  <Skeleton className="h-4 w-full" />
                  <Skeleton className="h-4 w-3/4" />
                </CardContent>
              </Card>
            ))}
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {clients.map((client) => (
              <Card
                key={client.id}
                className="h-[380px] hover:shadow-2xl transition-all duration-300 hover:-translate-y-2 border-emerald-50"
              >
                <CardContent className="pt-8 flex flex-col">
                  {/* Quote Icon */}
                  <div className="mb-6">
                    <Quote className="h-10 w-10 text-emerald-200" />
                  </div>

                  {/* Client Info */}
                  <div className="flex items-center gap-4 mb-6">
                    <Avatar className="h-20 w-20 ring-4 ring-emerald-50">
                      <AvatarImage src={client.imageUrl} alt={client.name} />
                      <AvatarFallback className="bg-gradient-to-br from-emerald-500 to-teal-500 text-white text-xl font-bold">
                        {client.name
                          .split(' ')
                          .map((n: string) => n[0])
                          .join('')
                          .toUpperCase()}
                      </AvatarFallback>
                    </Avatar>
                    <div>
                      <h3 className="font-bold text-xl text-slate-800 mb-1">
                        {client.name}
                      </h3>
                      <p className="text-emerald-600 font-medium">
                        {client.designation}
                      </p>
                    </div>
                  </div>

                  {/* Testimonial */}
                  <p className="text-slate-600 leading-relaxed flex-1 italic">
                    "{client.description}"
                  </p>

                  {/* Stars */}
                  <div className="flex gap-1 mt-6">
                    {[1, 2, 3, 4, 5].map((star) => (
                      <Star
                        key={star}
                        className="h-5 w-5 fill-amber-400 text-amber-400"
                      />
                    ))}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>
    </section>
  );
}
