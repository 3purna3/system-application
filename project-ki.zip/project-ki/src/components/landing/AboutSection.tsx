'use client';

import { Target, Code, Rocket, Heart } from 'lucide-react';

export function AboutSection() {
  return (
    <section id="about" className="py-20 md:py-32 bg-white">
      <div className="container mx-auto px-4 md:px-8">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          {/* Left Content */}
          <div className="space-y-6">
            <div className="inline-flex items-center rounded-full bg-emerald-100 px-4 py-2 text-sm font-medium text-emerald-700">
              About REAL TRUST
            </div>

            <h2 className="text-3xl md:text-4xl font-bold">
              We Create Digital Experiences That
              <span className="block bg-gradient-to-r from-emerald-600 to-teal-600 bg-clip-text text-transparent mt-2">
                Inspire & Convert
              </span>
            </h2>

            <p className="text-lg text-slate-600 leading-relaxed">
              REAL TRUST is a leading digital solutions provider specializing in web development,
              mobile applications, and enterprise systems. With over 10 years of experience,
              we've helped 500+ businesses transform their digital presence.
            </p>

            <p className="text-slate-600 leading-relaxed">
              Our team of expert developers, designers, and strategists work together
              to deliver solutions that not only meet but exceed your expectations. We believe
              in building long-term partnerships and growing together with our clients.
            </p>

            <div className="grid grid-cols-2 gap-4 pt-4">
              <div className="flex items-center gap-3">
                <div className="h-10 w-10 rounded-lg bg-emerald-100 flex items-center justify-center flex-shrink-0">
                  <Target className="h-5 w-5 text-emerald-600" />
                </div>
                <span className="font-medium">Goal Oriented</span>
              </div>
              <div className="flex items-center gap-3">
                <div className="h-10 w-10 rounded-lg bg-teal-100 flex items-center justify-center flex-shrink-0">
                  <Code className="h-5 w-5 text-teal-600" />
                </div>
                <span className="font-medium">Clean Code</span>
              </div>
              <div className="flex items-center gap-3">
                <div className="h-10 w-10 rounded-lg bg-emerald-100 flex items-center justify-center flex-shrink-0">
                  <Rocket className="h-5 w-5 text-emerald-600" />
                </div>
                <span className="font-medium">Fast Delivery</span>
              </div>
              <div className="flex items-center gap-3">
                <div className="h-10 w-10 rounded-lg bg-teal-100 flex items-center justify-center flex-shrink-0">
                  <Heart className="h-5 w-5 text-teal-600" />
                </div>
                <span className="font-medium">Client First</span>
              </div>
            </div>
          </div>

          {/* Right Content - Stats */}
          <div className="relative">
            <div className="bg-gradient-to-br from-emerald-50 to-teal-50 rounded-3xl p-8 md:p-12">
              <div className="grid grid-cols-2 gap-6">
                <div className="bg-white rounded-2xl p-6 text-center shadow-lg">
                  <div className="text-4xl font-bold text-emerald-600 mb-2">500+</div>
                  <div className="text-slate-600">Projects Delivered</div>
                </div>
                <div className="bg-white rounded-2xl p-6 text-center shadow-lg">
                  <div className="text-4xl font-bold text-teal-600 mb-2">50+</div>
                  <div className="text-slate-600">Team Members</div>
                </div>
                <div className="bg-white rounded-2xl p-6 text-center shadow-lg">
                  <div className="text-4xl font-bold text-emerald-600 mb-2">10+</div>
                  <div className="text-slate-600">Years Experience</div>
                </div>
                <div className="bg-white rounded-2xl p-6 text-center shadow-lg">
                  <div className="text-4xl font-bold text-teal-600 mb-2">98%</div>
                  <div className="text-slate-600">Happy Clients</div>
                </div>
              </div>

              <div className="mt-8 text-center">
                <p className="text-slate-600 italic">
                  "Our commitment to excellence drives everything we do."
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
